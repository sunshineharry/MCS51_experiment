#include"8051.h"
#include"ABSACC.H"
#define DAC0832 XBYTE[0x1000]