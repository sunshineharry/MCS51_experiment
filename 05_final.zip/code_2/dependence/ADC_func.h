#include "ADC.h"
extern void ADC_choose_INO();