#include "8051.h"
#include "ABSACC.H"
#define INO_ADDR XBYTE[0xE000]
#define ADC_INO XBYTE[0xE000]

