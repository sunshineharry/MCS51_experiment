#include "ADC.h"

void ADC_choose_INO()
{
    INO_ADDR = 0x00;
}