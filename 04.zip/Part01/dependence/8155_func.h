#include "8155.H"
extern void C8155_init(uchar command_2_8155);
// #undef C8155_CMD_ADDRESS
// #undef C8155_PA_ADDRESS
// #undef C8155_PB_ADDRESS
// #undef C8155_PC_ADDRESS