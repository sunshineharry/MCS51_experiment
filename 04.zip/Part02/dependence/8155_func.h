#include "8155.H"
extern void C8155_init(uchar command_2_8155);